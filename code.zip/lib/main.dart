import 'package:flutter/material.dart';
import 'Haldua.dart';
import 'Haltiga.dart';
import 'Halempat.dart';
import 'Hallima.dart';

void main() {
  runApp(MaterialApp(
    home: Halsatu(),
    routes: <String, WidgetBuilder>{
      '/Halsatu': (BuildContext context) => Halsatu(),
      '/Haldua': (BuildContext context) => Haldua(),
      '/Haltiga': (BuildContext context) => Haltiga(),
      '/HalEmpat': (BuildContext context) => HalEmpat(),
      '/Hallima': (BuildContext context) => Hallima(),
    },
  ));
}

class Halsatu extends StatelessWidget {
  Halsatu({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 92, 172, 238),
        title: const Text("Rumah Sakit Umum"),
      ),
      body: Container(
        child: Column(
          children: <Widget>[
            Image.asset(
              'assets/logo samping.png',
              width: 300,
              height: 150,
            ),
            InkWell(
              onTap: () {
                Navigator.pushNamed(context, '/Haldua');
              },
              child: Card(
                child: Container(
                  height: 220,
                  width: 200,
                  padding: EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.pushNamed(context, '/Haldua');
                        },
                        child: Column(
                          children: [
                            Image.asset(
                              'assets/pasien baru.png',
                              width: 100,
                              height: 100,
                            ),
                            Text(
                              "Pasien Baru",
                              style: TextStyle(fontSize: 20.0),
                            ),
                            Text(
                              "Khusus bagi yang BELUM PERNAH Menjadi Pasien Rumah Sakit Umum",
                              textAlign: TextAlign.center,
                              style: TextStyle(fontSize: 11.0),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            InkWell(
              onTap: () {
                Navigator.pushNamed(context, '/Haltiga');
              },
              child: Card(
                child: Container(
                  height: 220,
                  width: 200,
                  padding: EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.pushNamed(context, '/Haltiga');
                        },
                        child: Column(
                          children: [
                            Image.asset(
                              'assets/pasien lama.png',
                              width: 100,
                              height: 100,
                            ),
                            Text(
                              "Pasien Lama",
                              style: TextStyle(fontSize: 20.0),
                            ),
                            Text(
                              "Khusus bagi yang SUDAH PERNAH Menjadi Pasien Rumah Sakit Umum",
                              textAlign: TextAlign.center,
                              style: TextStyle(fontSize: 11.0),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            Container(
              padding: EdgeInsets.all(12.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Contact center : 112-80880 234",
                    style: TextStyle(fontSize: 12),
                  ),
                  SizedBox(width: 20),
                  Icon(Icons.message, size: 15),
                  SizedBox(width: 5),
                  Text(
                    "081918232654",
                    style: TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
