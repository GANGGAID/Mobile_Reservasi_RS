import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp());
}

// ignore: must_be_immutable
class Haltiga extends StatelessWidget {
  String teks = "";
  TextEditingController no = TextEditingController();
  TextEditingController lahir = TextEditingController();

  Haltiga({super.key});

  void _alertdialog(String str) {
    if (str.isEmpty) return;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: const Color.fromARGB(255, 92, 172, 238),
          title: const Text("Data Diri Pasien")),
      body: Container(
        padding: EdgeInsets.all(50.0),
        child: Column(
          children: <Widget>[
            Image.asset(
              'assets/logo.png',
              width: 250,
              height: 250,
            ),
            Text(
              teks,
              style: TextStyle(fontSize: 20.0),
            ),
            TextField(
              controller: no,
              decoration: InputDecoration(
                hintText: "No. Rekaman Medis",
              ),
              onSubmitted: (String str) {
                _alertdialog(str);
              },
            ),
            TextField(
              controller: lahir,
              decoration: InputDecoration(
                hintText: "Tanggal Lahir",
              ),
              onSubmitted: (String str) {
                _alertdialog(str);
              },
            ),
            Container(
              padding: EdgeInsets.all(12.0),
              child: ElevatedButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text('Selamat'),
                        content: Text('Login Berhasil'),
                        actions: <Widget>[
                          TextButton(
                            onPressed: () {
                              Navigator.pushNamed(context, '/HalEmpat');
                            },
                            style: ElevatedButton.styleFrom(
                                foregroundColor: Colors.blue),
                            child: Text('Selanjutnya'),
                          ),
                        ],
                      );
                    },
                  );
                },
                child: Text('Login'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
