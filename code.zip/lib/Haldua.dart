import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp());
}

// ignore: must_be_immutable
class Haldua extends StatelessWidget {
  String teks = "";
  TextEditingController nik = TextEditingController();
  TextEditingController nama = TextEditingController();
  TextEditingController tanggallahir = TextEditingController();
  TextEditingController jeniskelamin = TextEditingController();
  TextEditingController alamat = TextEditingController();

  Haldua({super.key});

  void _alertdialog(String str) {
    if (str.isEmpty) return;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            backgroundColor: Color.fromARGB(255, 74, 144, 202),
            title: const Text("Pendaftaran Pasien Baru")),
        body: Container(
            padding: EdgeInsets.all(50.0),
            child: Column(
              children: <Widget>[
                Image.asset(
                  'assets/logo.png',
                  width: 250,
                  height: 250,
                ),
                Text(
                  teks,
                  style: TextStyle(fontSize: 20.0),
                ),
                TextField(
                  controller: nik,
                  decoration: InputDecoration(
                    hintText: "Nik",
                  ),
                  onSubmitted: (String str) {
                    _alertdialog(str);
                  },
                ),
                TextField(
                  controller: nama,
                  decoration: InputDecoration(
                    hintText: "Nama",
                  ),
                  onSubmitted: (String str) {
                    _alertdialog(str);
                  },
                ),
                TextField(
                  controller: tanggallahir,
                  decoration: InputDecoration(
                    hintText: "Tanggal Lahir",
                  ),
                  onSubmitted: (String str) {
                    _alertdialog(str);
                  },
                ),
                TextField(
                  controller: jeniskelamin,
                  decoration: InputDecoration(
                    hintText: "Jenis Kelamin",
                  ),
                  onSubmitted: (String str) {
                    _alertdialog(str);
                  },
                ),
                TextField(
                  controller: alamat,
                  decoration: InputDecoration(
                    hintText: "Alamat",
                  ),
                  onSubmitted: (String str) {
                    _alertdialog(str);
                  },
                ),
                Container(
                  padding: EdgeInsets.all(12.0),
                  child: ElevatedButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text('Selamat'),
                            content: Text('Pendaftaran Berhasil'),
                            actions: <Widget>[
                              TextButton(
                                onPressed: () {
                                  Navigator.pushNamed(context, '/HalEmpat');
                                },
                                child: Text('Selanjutnya'),
                              ),
                            ],
                          );
                        },
                      );
                    },
                    child: Text('Daftar'),
                  ),
                ),
              ],
            )));
  }
}
